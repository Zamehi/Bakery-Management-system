package com.example.sda_project23;

import BL.Admin;
import BL.BakeryControllor;
import DB_handler.database_connection;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.*;

public class loginControllor
{
    @FXML
    private Label afterLoginText;
    @FXML
    private TextField userText;
    @FXML
    private TextField passwordText;
    @FXML
    private Button cancelButton;
    @FXML
    private Button loginButton;

    @FXML
    protected void onloginButtonClick(ActionEvent e)
    {
        if (userText.getText().isBlank()== false && passwordText.getText().isBlank()== false)
        {
            validateLogin();
        }

    }
    @FXML
    protected void oncancelButtonClick(ActionEvent e)
    {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }
    public void validateLogin()
    {
        BL.BakeryControllor b = new BakeryControllor();
        int x = 0;

        x = b.admin.login(userText.getText(), passwordText.getText());
        if (x == 1)
        {
            afterLoginText.setText("Logged in successfully");
        }
        else if (x== 0)

        {
            afterLoginText.setText("Invalid Login");
        }
        else if (x == -1)
        {
            afterLoginText.setText("unknown error");
        }

                // returning connection from function of object of the class
    }

}
