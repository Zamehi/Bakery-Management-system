package BL;
public class CashOnDelivery {
}
