package BL;

public class Customer
{

}
