package BL;
public class Order
{
    int order_no;
    int amount;
    String status;
}
