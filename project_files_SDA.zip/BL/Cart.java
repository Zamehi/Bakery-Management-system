package BL;

public class Cart
{
    BakeryItems B[];
}
