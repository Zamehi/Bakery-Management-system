package BL;
public class BakeryControllor
{
    public Admin admin = new Admin();
    public BakeryControllor()
    {

    }


}
