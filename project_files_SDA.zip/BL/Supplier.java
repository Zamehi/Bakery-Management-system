package BL;

public class Supplier {
}
