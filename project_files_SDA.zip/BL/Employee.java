package BL;

public class Employee
{
    String EID;
    int salary;
    int work_hours;
}
