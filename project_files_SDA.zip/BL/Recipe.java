package BL;
public class Recipe
{
    String text;
    Ingredients I[];
}
