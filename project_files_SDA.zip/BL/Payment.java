package BL;

public class Payment
{
    int amount;
    String status;
}
