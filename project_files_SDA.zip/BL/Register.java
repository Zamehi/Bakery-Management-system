package BL;
public class Register {
}
