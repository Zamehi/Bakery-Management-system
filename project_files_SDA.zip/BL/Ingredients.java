package BL;

public class Ingredients
{
    String name;
    int number ;
    int quantity;

}
