package BL;
public class Discount
{
    int amount;
    int time;

}
