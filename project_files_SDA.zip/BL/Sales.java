package BL;

public class Sales
{
    int budget;

}
