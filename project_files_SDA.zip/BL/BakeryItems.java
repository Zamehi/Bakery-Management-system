package BL;

public class BakeryItems
{
    int number;
    int quantity;
    String review;
    String name;
    String comdition;
    int price;
    int discount;

}
