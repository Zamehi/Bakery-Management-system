package BL;
public class Inventory {
}
