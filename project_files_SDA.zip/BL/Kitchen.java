package BL;

public class Kitchen {
}
